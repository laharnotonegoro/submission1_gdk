package com.example.submission1.main;

import android.content.res.TypedArray;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.submission1.MovieModel;
import com.example.submission1.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.lv_list);

        String[] judul = getResources().getStringArray(R.array.movie_judul);
        TypedArray poster = getResources().obtainTypedArray(R.array.movie_poster);
        String[] dekripsi = getResources().getStringArray((R.array.movie_deskripsi));

        ArrayList<MovieModel> movies = new ArrayList<>();
        for (int i=1; i<=judul.length; i++) {
            movies.add(new MovieModel(judul[i-1], dekripsi[i-1], poster.getResourceId(i-1, 0)));
        }

        MovieAdapter adapter = new MovieAdapter(this, movies);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }
}
